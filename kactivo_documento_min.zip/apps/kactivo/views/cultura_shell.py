from django.shortcuts import render

def inicio(request):
    return render(request, "cursos/inicio.html")

def participante(request):
    return render(request, "cursos/participante.html")

def docente(request):
    return render(request, "cursos/docente.html")

def cursos(request):
    return render(request, "cursos/cursos.html")

def cargue_documental(request):
    return render(request, "cursos/cargue_documental.html")

def consultas(request):
    return render(request, "cursos/consultas.html")

def asistencia(request):
    # Solo UI shell. La lógica real la hace `consulta_asistencia_cultura`
    return render(request, "cursos/asistencia.html")