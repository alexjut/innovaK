from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from django.db import IntegrityError, transaction

from ..models import Candidate, Event, Vote


@dataclass
class VoteResult:
    ok: bool
    error: Optional[str] = None
    already_voted: bool = False
    vote_id: Optional[int] = None


def register_vote(
    *,
    event_id: int,
    candidate_id: int,
    first_name: str,
    last_name: str,
    phone: str,
    email: str,
    address: str = "",
    consent_accepted: bool = False,
    ip: str = "",
    user_agent: str = "",
) -> VoteResult:
    """
    Registra un voto público.
    Regla: 1 voto por email por evento.

    Nota:
    - Las validaciones básicas (campos requeridos, evento/candidato activos) ya vienen
      desde la vista, pero aquí volvemos a validar lo crítico para mantener consistencia.
    """

    # Normalización mínima
    email = (email or "").strip().lower()
    first_name = (first_name or "").strip()
    last_name = (last_name or "").strip()
    phone = (phone or "").strip()
    address = (address or "").strip()
    ip = (ip or "").strip()
    user_agent = (user_agent or "").strip()

    if not email:
        return VoteResult(ok=False, error="Correo requerido.")
    if not consent_accepted:
        return VoteResult(ok=False, error="Debes aceptar la política de datos.")

    try:
        with transaction.atomic():
            # Lock suave para evitar carreras en alta concurrencia
            event = (
                Event.objects.select_for_update()
                .filter(id=event_id)
                .first()
            )
            if not event:
                return VoteResult(ok=False, error="El evento no existe.")
            if not event.is_active:
                return VoteResult(ok=False, error="El evento está inactivo.")

            candidate = (
                Candidate.objects.select_for_update()
                .filter(id=candidate_id)
                .first()
            )
            if not candidate:
                return VoteResult(ok=False, error="El artista no existe.")
            if not candidate.is_active:
                return VoteResult(ok=False, error="El artista está inactivo.")
            if candidate.event_id != event.id:
                return VoteResult(ok=False, error="El artista no pertenece a este evento.")

            # Regla principal: un voto por email por evento
            already = Vote.objects.filter(event_id=event.id, voter_email__iexact=email).first()
            if already:
                return VoteResult(
                    ok=False,
                    error="Este correo ya registró un voto en este evento.",
                    already_voted=True,
                    vote_id=already.id,
                )

            # Crea el voto
            vote = Vote.objects.create(
                event_id=event.id,
                candidate_id=candidate.id,
                voter_first_name=first_name,
                voter_last_name=last_name,
                voter_phone=phone,
                voter_email=email,
                voter_address=address,
                consent_accepted=bool(consent_accepted),
                ip_address=ip,
                user_agent=user_agent,
            )

            return VoteResult(
                ok=True,
                already_voted=False,
                vote_id=vote.id,
            )

    except IntegrityError:
        # Por si tienes UniqueConstraint en DB (recomendado)
        existing = Vote.objects.filter(event_id=event_id, voter_email__iexact=email).first()
        if existing:
            return VoteResult(
                ok=False,
                error="Este correo ya registró un voto en este evento.",
                already_voted=True,
                vote_id=existing.id,
            )
        return VoteResult(ok=False, error="Conflicto de integridad al registrar el voto.")

    except Exception as e:
        return VoteResult(ok=False, error=f"Error registrando voto: {e}")