from django.db import models

from .candidate import Candidate
from .event import Event
from .voter import Voter


class Vote(models.Model):
    event = models.ForeignKey(
        Event,
        on_delete=models.PROTECT,
        related_name="votes",
        db_column="event_id",
    )

    candidate = models.ForeignKey(
        Candidate,
        on_delete=models.PROTECT,
        related_name="votes",
        db_column="candidate_id",
    )

    voter = models.ForeignKey(
        Voter,
        on_delete=models.PROTECT,
        related_name="votes",
        db_column="voter_id",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    # Habeas Data / consentimiento
    consent_accepted = models.BooleanField(default=False)
    consent_accepted_at = models.DateTimeField(null=True, blank=True)

    # Trazabilidad / antifraude
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True, default="")

    class Meta:
        db_table = "votaciones_vote"
        indexes = [
            models.Index(fields=["created_at"], name="idx_vote_created"),
            models.Index(fields=["event", "created_at"], name="idx_vote_event_created"),
            models.Index(fields=["event", "candidate", "created_at"], name="idx_vote_evt_cand_created"),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["event", "voter"],
                name="uniq_vote_per_event_voter",
            ),
        ]
        managed = False  # ✅ BD externa

    def __str__(self):
        return f"Vote(event={self.event_id}, candidate={self.candidate_id}, voter={self.voter_id})"