from django.urls import path
from . import views


app_name = "votaciones"

urlpatterns = [
    # ==========================
    # Auth staff
    # ==========================
    path("login/", views.staff_login, name="staff_login"),
    path("logout/", views.staff_logout, name="staff_logout"),

    # ==========================
    # UI (votación)
    # ==========================
    path("", views.redirect_root, name="root"),  # si ya tienes redirect_root en views.py
    path("scan/", views.scan_page, name="scan"),
    path("dashboard/", views.dashboard_page, name="dashboard"),

    # ==========================
    # Organizador (CRUD artistas)
    # ==========================
    path("organizador/artistas/", views.organizer_artists, name="organizer_artists"),
    path(
        "organizador/artistas/<int:candidate_id>/editar/",
        views.organizer_artist_edit,
        name="organizer_artist_edit",
    ),
    path(
        "organizador/artistas/<int:candidate_id>/toggle/",
        views.organizer_artist_toggle,
        name="organizer_artist_toggle",
    ),

    # ==========================
    # Organizador (CRUD eventos)
    # ==========================
    path("organizador/eventos/", views.organizer_events, name="organizer_events"),
    path("organizador/eventos/nuevo/", views.organizer_event_create, name="organizer_event_create"),
    path(
        "organizador/eventos/<int:event_id>/editar/",
        views.organizer_event_edit,
        name="organizer_event_edit",
    ),
    path(
        "organizador/eventos/<int:event_id>/toggle/",
        views.organizer_event_toggle,
        name="organizer_event_toggle",
    ),

    # ==========================
    # QR
    # ==========================
    path("qr/event/<int:event_id>.png", views.qr_event_png, name="qr_event_png"),
    path("qr/candidate/<int:candidate_id>.png", views.qr_candidate_png, name="qr_candidate_png"),

    # ==========================
    # API votación
    # ==========================
    path("api/events/", views.api_events, name="api_events"),
    path("api/events/<int:event_id>/candidates/", views.api_event_candidates, name="api_event_candidates"),
    path("api/results/", views.api_results, name="api_results"),
    path("api/vote/", views.api_vote, name="api_vote"),
]