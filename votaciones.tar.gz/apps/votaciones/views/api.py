import json
from urllib.parse import quote

from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.staticfiles import finders
from django.db.models import Count
from django.http import HttpRequest, JsonResponse
from django.shortcuts import get_object_or_404
from django.templatetags.static import static as static_url
from django.utils.timezone import localtime
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_http_methods

from ..models import Candidate, Event, Vote
from ..services import register_vote


# =============================================================================
# Helpers (movidos desde views.py original)
# =============================================================================

def get_client_ip(request: HttpRequest) -> str:
    """Retorna la IP del cliente. (Si hay proxy, usa X-Forwarded-For)."""
    xff = request.META.get("HTTP_X_FORWARDED_FOR")
    if xff:
        return xff.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "") or ""


def _dt_iso(dt):
    """Fechas en ISO para JSON."""
    if not dt:
        return None
    try:
        return localtime(dt).isoformat()
    except Exception:
        try:
            return dt.isoformat()
        except Exception:
            return None


def _json_error(message: str, status: int = 400, extra: dict | None = None):
    payload = {"ok": False, "error": message}
    if extra:
        payload.update(extra)
    return JsonResponse(payload, status=status)


def _parse_bool(val) -> bool:
    """Acepta True/False, 1/0, 'true'/'false'."""
    if val is True:
        return True
    if val in (1, "1"):
        return True
    if isinstance(val, str) and val.strip().lower() in ("true", "yes", "si", "sí"):
        return True
    return False


def _media_file_exists(field) -> bool:
    """
    Verifica si el archivo realmente existe en el storage.
    En entornos sin MEDIA persistente, esto normalmente será False.
    """
    if not field:
        return False
    try:
        name = getattr(field, "name", "") or ""
        if not name:
            return False
        storage = getattr(field, "storage", None)
        if not storage:
            return False
        return storage.exists(name)
    except Exception:
        return False


def _static_candidate_url(request: HttpRequest, filename: str) -> str | None:
    """
    Retorna URL absoluta a un archivo en static/voting/candidates/ si existe.

    IMPORTANTE:
    - Primero static(), luego quote() sobre URL final (para no romper manifest/hashes).
    """
    filename = (filename or "").strip()
    if not filename:
        return None

    rel_path = f"voting/candidates/{filename}"

    try:
        exists = bool(finders.find(rel_path))
    except Exception:
        exists = False

    if not exists:
        return None

    url_path = static_url(rel_path)
    safe_url_path = quote(url_path, safe="/:?&=#%._-~")
    return request.build_absolute_uri(safe_url_path)


def _candidate_photo_url(request: HttpRequest, c: Candidate) -> str:
    """
    Foto del candidato:
    1) MEDIA (solo si el archivo existe)
    2) STATIC por filename exacto en c.code
    3) STATIC por nombre artístico + extensiones comunes
    4) placeholder
    """

    # 1) MEDIA
    if getattr(c, "photo", None) and _media_file_exists(c.photo):
        try:
            return request.build_absolute_uri(c.photo.url)
        except Exception:
            pass

    # 2) STATIC usando c.code como filename exacto (ej: 'Amazonas.jpeg')
    url = _static_candidate_url(request, getattr(c, "code", ""))
    if url:
        return url

    # 3) STATIC usando nombre del artista
    base = (getattr(c, "name", "") or "").strip()
    if base:
        for ext in (".png", ".jpg", ".jpeg", ".webp"):
            url = _static_candidate_url(request, f"{base}{ext}")
            if url:
                return url

        url = _static_candidate_url(request, base)
        if url:
            return url

    # 4) placeholder
    return request.build_absolute_uri(static_url("voting/candidates/placeholder.png"))


# =============================================================================
# API pública
# =============================================================================

@require_GET
def api_events(request: HttpRequest):
    """Lista eventos activos para el selector del frontend (público)."""
    events = (
        Event.objects.filter(is_active=True)
        .order_by("-created_at")
        .values("id", "name", "starts_at", "ends_at")
    )

    out = []
    for e in events:
        out.append(
            {
                "id": e["id"],
                "name": e["name"],
                "starts_at": _dt_iso(e["starts_at"]),
                "ends_at": _dt_iso(e["ends_at"]),
            }
        )

    return JsonResponse({"ok": True, "events": out})


@require_GET
def api_event_candidates(request: HttpRequest, event_id: int):
    """Devuelve los candidatos activos de un evento (público)."""
    event = get_object_or_404(Event, pk=event_id)

    if not event.is_active:
        return _json_error("Este evento está inactivo.", status=403)

    candidates = (
        Candidate.objects.filter(event=event, is_active=True)
        .order_by("stage_order", "id")
    )

    data = []
    for c in candidates:
        data.append(
            {
                "id": c.id,
                "name": c.name,
                "genre": c.genre or "",
                "code": c.code or "",
                "photo_url": _candidate_photo_url(request, c),
                "bio": c.bio or "",
                "instagram": c.instagram or "",
                "tiktok": c.tiktok or "",
                "youtube": c.youtube or "",
                "stage_order": c.stage_order,
                "is_active": bool(c.is_active),
                "event_id": c.event_id,
            }
        )

    return JsonResponse(
        {
            "ok": True,
            "event": {
                "id": event.id,
                "name": event.name,
                "starts_at": _dt_iso(event.starts_at),
                "ends_at": _dt_iso(event.ends_at),
            },
            "count": len(data),
            "candidates": data,
        }
    )


# =============================================================================
# API SOLO STAFF
# =============================================================================

@staff_member_required(login_url="staff_login")
@require_GET
def api_results(request: HttpRequest):
    """Ranking de votos por evento (SOLO STAFF)."""
    try:
        event_id = int(request.GET.get("event") or "0")
    except ValueError:
        return _json_error("event inválido", status=400)

    if event_id == 0:
        e = Event.objects.filter(is_active=True).order_by("-created_at").first()
        if not e:
            return JsonResponse(
                {
                    "ok": True,
                    "event": None,
                    "total_votes": 0,
                    "unique_voters": 0,
                    "ranking": [],
                }
            )
        event_id = e.id

    rows = (
        Vote.objects.filter(event_id=event_id)
        .values("candidate_id", "candidate__name")
        .annotate(votes=Count("id"))
        .order_by("-votes", "candidate__name")
    )

    total = Vote.objects.filter(event_id=event_id).count()
    unique = Vote.objects.filter(event_id=event_id).values("voter_id").distinct().count()
    event = Event.objects.filter(id=event_id).values("id", "name").first()

    return JsonResponse(
        {
            "ok": True,
            "event": event,
            "total_votes": total,
            "unique_voters": unique,
            "ranking": list(rows),
        }
    )


# =============================================================================
# API pública: votar
# =============================================================================

@csrf_exempt
@require_http_methods(["POST"])
def api_vote(request: HttpRequest):
    """Registra voto: 1 voto por persona (email) por evento (público)."""
    try:
        data = json.loads(request.body.decode("utf-8"))
    except Exception:
        return _json_error("JSON inválido", status=400)

    try:
        event_id = int(data.get("event_id") or 0)
        candidate_id = int(data.get("candidate_id") or 0)
    except ValueError:
        return _json_error("event_id/candidate_id inválidos", status=400)

    if not event_id or not candidate_id:
        return _json_error("Faltan event_id o candidate_id", status=400)

    first_name = str(data.get("first_name", "")).strip()
    last_name = str(data.get("last_name", "")).strip()
    phone = str(data.get("phone", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    address = str(data.get("address", "")).strip()

    consent_accepted = _parse_bool(data.get("consent_accepted"))

    if not first_name:
        return _json_error("Nombre requerido.", status=400)
    if not last_name:
        return _json_error("Apellido requerido.", status=400)
    if not phone:
        return _json_error("Teléfono requerido.", status=400)
    if not email:
        return _json_error("Correo requerido.", status=400)
    if not consent_accepted:
        return _json_error("Debes aceptar la política de datos.", status=400)

    event = Event.objects.filter(id=event_id).first()
    if not event:
        return _json_error("El evento no existe.", status=404)
    if not event.is_active:
        return _json_error("El evento está inactivo.", status=403)

    candidate = Candidate.objects.select_related("event").filter(id=candidate_id).first()
    if not candidate:
        return _json_error("El artista no existe.", status=404)
    if not candidate.is_active:
        return _json_error("El artista está inactivo.", status=403)
    if candidate.event_id != event_id:
        return _json_error("El artista no pertenece a este evento.", status=409)

    ip = get_client_ip(request)
    ua = request.META.get("HTTP_USER_AGENT", "") or ""

    res = register_vote(
        event_id=event_id,
        candidate_id=candidate_id,
        first_name=first_name,
        last_name=last_name,
        phone=phone,
        email=email,
        address=address,
        consent_accepted=consent_accepted,
        ip=ip,
        user_agent=ua,
    )

    if not getattr(res, "ok", False):
        err = getattr(res, "error", None) or "No fue posible registrar el voto."
        return _json_error(err, status=400)

    return JsonResponse(
        {
            "ok": True,
            "already_voted": bool(getattr(res, "already_voted", False)),
            "vote_id": getattr(res, "vote_id", None),
        }
    )