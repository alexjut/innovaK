from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect, render
from django.http import HttpRequest


def redirect_root(request: HttpRequest):
    return redirect("votaciones:scan")


def scan_page(request: HttpRequest):
    return render(request, "votaciones/scan.html")


@staff_member_required(login_url="votaciones:staff_login")
def dashboard_page(request: HttpRequest):
    return render(request, "votaciones/dashboard.html")