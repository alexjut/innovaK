from django import forms

from ..models import Candidate


class CandidateForm(forms.ModelForm):
    class Meta:
        model = Candidate
        fields = [
            "event",
            "name",
            "genre",
            "code",
            "photo",
            "bio",
            "instagram",
            "tiktok",
            "youtube",
            "stage_order",
            "is_active",
        ]
        widgets = {
            "event": forms.Select(attrs={"class": "form-select"}),
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "genre": forms.TextInput(attrs={"class": "form-control"}),
            "code": forms.TextInput(attrs={"class": "form-control"}),
            "photo": forms.ClearableFileInput(attrs={"class": "form-control"}),
            "bio": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
            "instagram": forms.URLInput(attrs={"class": "form-control"}),
            "tiktok": forms.URLInput(attrs={"class": "form-control"}),
            "youtube": forms.URLInput(attrs={"class": "form-control"}),
            "stage_order": forms.NumberInput(attrs={"class": "form-control", "min": 0}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def clean_stage_order(self):
        value = self.cleaned_data.get("stage_order")
        if value is None:
            return 0
        if value < 0:
            raise forms.ValidationError("El orden en tarima no puede ser negativo.")
        return value

    def clean_code(self):
        code = (self.cleaned_data.get("code") or "").strip()
        return code

    def clean_name(self):
        name = (self.cleaned_data.get("name") or "").strip()
        if not name:
            raise forms.ValidationError("El nombre del artista es obligatorio.")
        return name