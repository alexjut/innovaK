from django import forms

from ..models import Event


class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ["name", "starts_at", "ends_at", "is_active"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "starts_at": forms.DateTimeInput(
                attrs={"class": "form-control", "type": "datetime-local"},
                format="%Y-%m-%dT%H:%M",
            ),
            "ends_at": forms.DateTimeInput(
                attrs={"class": "form-control", "type": "datetime-local"},
                format="%Y-%m-%dT%H:%M",
            ),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field_name in ("starts_at", "ends_at"):
            value = self.initial.get(field_name)
            if value:
                try:
                    self.initial[field_name] = value.strftime("%Y-%m-%dT%H:%M")
                except Exception:
                    pass

    def clean(self):
        cleaned = super().clean()
        starts_at = cleaned.get("starts_at")
        ends_at = cleaned.get("ends_at")
        if starts_at and ends_at and ends_at <= starts_at:
            self.add_error("ends_at", "La fecha/hora de finalización debe ser mayor que la de inicio.")
        return cleaned